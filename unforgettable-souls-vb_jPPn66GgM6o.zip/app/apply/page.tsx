'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { PLANS, type PlanId } from '@/lib/pricing'
import { ArrowLeft, Check, Shield } from 'lucide-react'

function ApplyContent() {
  const searchParams = useSearchParams()
  const planId = searchParams.get('plan') as PlanId | null
  const [selectedPlan, setSelectedPlan] = useState<typeof PLANS[PlanId] | null>(
    null
  )

  useEffect(() => {
    if (planId && planId in PLANS) {
      setSelectedPlan(PLANS[planId])
    }
  }, [planId])

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <Button asChild variant="ghost" className="mb-8">
        <Link href="/pricing" className="flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Pricing
        </Link>
      </Button>

      <div className="text-center mb-12 space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
          <Shield className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">Secure Application</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-balance">
          Apply for Coverage
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
          You're one step away from securing your family's future with
          blockchain-powered life insurance.
        </p>
      </div>

      {selectedPlan && (
        <Card className="mb-8 border-primary">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Selected Plan: {selectedPlan.name}</CardTitle>
              <Badge variant="secondary">
                ${selectedPlan.monthlyPrice}/month
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Coverage:</span>
                <span className="font-medium">{selectedPlan.coverage}</span>
              </div>
              <ul className="space-y-2">
                {selectedPlan.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-primary shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Complete Your Application</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-primary/5 rounded-lg p-6 border border-primary/20">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Pi Network Authentication Required
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              To continue with your application, please authenticate with your Pi
              Network account. This ensures secure access to your blockchain
              rewards and policy management.
            </p>
            <Button className="w-full" size="lg">
              Sign In with Pi Network
            </Button>
          </div>

          <div className="space-y-4 text-sm text-muted-foreground">
            <p>After signing in, you'll be able to:</p>
            <ul className="space-y-2 ml-4">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <span>Complete your full application</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <span>Link your Pi Network wallet</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <span>Start earning blockchain rewards</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <span>Access your policy dashboard</span>
              </li>
            </ul>
          </div>

          <div className="border-t pt-4">
            <p className="text-xs text-muted-foreground text-center">
              By continuing, you agree to our Terms of Service and Privacy Policy.
              Your information is encrypted and secured on the blockchain.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="mt-8 text-center">
        <p className="text-sm text-muted-foreground mb-4">
          Don't have a plan selected yet?
        </p>
        <Button asChild variant="outline">
          <Link href="/pricing">View All Plans</Link>
        </Button>
      </div>
    </div>
  )
}

export default function ApplyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Suspense fallback={
        <div className="container mx-auto px-4 py-12 text-center">
          <p>Loading...</p>
        </div>
      }>
        <ApplyContent />
      </Suspense>
    </div>
  )
}
