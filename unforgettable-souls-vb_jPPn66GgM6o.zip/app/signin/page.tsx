import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Shield } from 'lucide-react'

export const metadata = {
  title: 'Sign In - Unforgettable Souls',
  description: 'Sign in to your Unforgettable Souls account with Pi Network',
}

export default function SignInPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <Button asChild variant="ghost" className="mb-4">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </Button>

        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">
              Secure Authentication
            </span>
          </div>
          <h1 className="text-3xl font-bold">Welcome Back</h1>
          <p className="text-muted-foreground">
            Sign in to access your policy and rewards
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Sign In with Pi Network</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Use your Pi Network credentials to securely access your
              Unforgettable Souls account and manage your life insurance policy.
            </p>

            <Button className="w-full" size="lg">
              <Shield className="w-4 h-4 mr-2" />
              Authenticate with Pi Network
            </Button>

            <div className="space-y-2 pt-4 border-t">
              <p className="text-xs text-muted-foreground text-center">
                Benefits of signing in:
              </p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• View your policy details and coverage</li>
                <li>• Track your blockchain rewards and staking</li>
                <li>• Make premium payments with Pi</li>
                <li>• Access your policy documents</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <div className="text-center text-sm">
          <p className="text-muted-foreground mb-4">
            Don't have a policy yet?
          </p>
          <div className="flex gap-3 justify-center">
            <Button asChild variant="outline">
              <Link href="/pricing">View Plans</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
