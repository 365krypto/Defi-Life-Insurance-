import { PricingTable } from '@/components/pricing-table'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export const metadata = {
  title: 'Pricing Plans - Unforgettable Souls',
  description:
    'Choose the perfect life insurance plan for your needs. Affordable premiums with blockchain-backed coverage.',
}

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        <Button
          asChild
          variant="ghost"
          className="mb-8"
        >
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </Button>

        <div className="text-center mb-12 space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-balance">
            Choose Your Plan
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Transparent pricing with no hidden fees. All plans include
            blockchain-secured coverage and mining rewards.
          </p>
        </div>

        <PricingTable />

        <div className="mt-16 text-center space-y-4">
          <p className="text-sm text-muted-foreground">
            Need help choosing the right plan?
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Button asChild variant="outline">
              <Link href="/contact">Contact Support</Link>
            </Button>
            <Button asChild variant="outline">
              <a href="mailto:support@unforgettablesouls.com">Email Us</a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
