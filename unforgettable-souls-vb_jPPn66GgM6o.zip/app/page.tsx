import { Hero } from "@/components/hero"
import { Features } from "@/components/features"
import { HowItWorks } from "@/components/how-it-works"
import { Benefits } from "@/components/benefits"
import { CTA } from "@/components/cta"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <Features />
      <HowItWorks />
      <Benefits />
      <CTA />
    </div>
  )
}
