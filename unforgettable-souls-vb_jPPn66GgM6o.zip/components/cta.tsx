import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { QuoteDialog } from '@/components/quote-dialog'
import { ArrowRight } from 'lucide-react'

export function CTA() {
  return (
    <section className="px-4 py-20">
      <div className="max-w-md mx-auto">
        <Card className="p-8 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground border-0 shadow-2xl">
          <div className="space-y-6 text-center">
            <h2 className="text-3xl font-bold text-balance">
              Start Building Your Legacy Today
            </h2>
            <p className="text-primary-foreground/90 leading-relaxed text-pretty">
              Join thousands of Pi Network members securing their family's
              future with blockchain-powered life insurance
            </p>
            <QuoteDialog>
              <Button
                size="lg"
                variant="secondary"
                className="w-full text-base h-14 rounded-xl group"
              >
                Get Your Quote
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </QuoteDialog>
            <div className="flex gap-2">
              <Button asChild variant="outline" size="sm" className="flex-1 bg-primary-foreground/10 hover:bg-primary-foreground/20 border-primary-foreground/30 text-primary-foreground">
                <Link href="/pricing">View Plans</Link>
              </Button>
              <Button asChild variant="outline" size="sm" className="flex-1 bg-primary-foreground/10 hover:bg-primary-foreground/20 border-primary-foreground/30 text-primary-foreground">
                <Link href="/contact">Contact</Link>
              </Button>
            </div>
            <p className="text-sm text-primary-foreground/70">
              No credit card required • Join with Pi Network
            </p>
          </div>
        </Card>

        <div className="mt-12 text-center space-y-4">
          <p className="text-sm text-muted-foreground">
            Powered by Pi Network & Blockchain Technology
          </p>
          <div className="flex items-center justify-center gap-6 text-xs text-muted-foreground">
            <span>Secure</span>
            <span>•</span>
            <span>Transparent</span>
            <span>•</span>
            <span>Affordable</span>
          </div>
        </div>
      </div>
    </section>
  )
}
