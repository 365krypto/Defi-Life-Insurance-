import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { QuoteDialog } from '@/components/quote-dialog'
import { Shield, TrendingUp } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5 px-4 py-20">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=400')] opacity-5 bg-cover bg-center" />

      <div className="relative z-10 max-w-md mx-auto text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
          <Shield className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">
            Blockchain-Secured Insurance
          </span>
        </div>

        <h1 className="text-5xl font-bold leading-tight text-balance">
          Unforgettable Life
        </h1>

        <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
          Whole life insurance that grows with blockchain rewards. Affordable
          premiums, transparent coverage, and lasting financial security for
          your family.
        </p>

        <div className="flex flex-col gap-3 pt-4">
          <QuoteDialog>
            <Button size="lg" className="w-full text-base h-14 rounded-xl">
              Get a Quote
            </Button>
          </QuoteDialog>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="w-full text-base h-14 rounded-xl bg-transparent"
          >
            <Link href="/pricing">View Pricing</Link>
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 pt-4 text-sm">
          <Button asChild variant="ghost" size="sm">
            <Link href="/contact">Contact Us</Link>
          </Button>
          <span className="text-muted-foreground hidden sm:inline">•</span>
          <Button asChild variant="ghost" size="sm">
            <Link href="/signin">Sign In</Link>
          </Button>
        </div>

        <div className="flex items-center justify-center gap-8 pt-8 text-sm">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-secondary" />
            <span className="text-muted-foreground">Coverage Grows</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <span className="text-muted-foreground">Blockchain Secured</span>
          </div>
        </div>
      </div>
    </section>
  )
}
