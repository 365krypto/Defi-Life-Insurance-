'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { PLANS, type PlanId } from '@/lib/pricing'
import { Check } from 'lucide-react'

export function PricingTable() {
  const [isAnnual, setIsAnnual] = useState(false)

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-center gap-3">
        <Label
          htmlFor="billing-toggle"
          className={!isAnnual ? 'font-semibold' : 'text-muted-foreground'}
        >
          Monthly
        </Label>
        <Switch
          id="billing-toggle"
          checked={isAnnual}
          onCheckedChange={setIsAnnual}
        />
        <Label
          htmlFor="billing-toggle"
          className={isAnnual ? 'font-semibold' : 'text-muted-foreground'}
        >
          Annual
        </Label>
        {isAnnual && (
          <Badge variant="secondary" className="ml-2">
            Save 10%
          </Badge>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {Object.entries(PLANS).map(([key, plan]) => {
          const price = isAnnual ? plan.annualPrice : plan.monthlyPrice
          const priceLabel = isAnnual ? '/year' : '/month'
          const isPopular = key === 'standard'

          return (
            <Card
              key={key}
              className={`relative ${
                isPopular
                  ? 'border-primary shadow-lg scale-105'
                  : 'border-border'
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">${price}</span>
                  <span className="text-muted-foreground">{priceLabel}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  Coverage: {plan.coverage}
                </p>
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  asChild
                  variant={isPopular ? 'default' : 'outline'}
                  className="w-full mt-6"
                  size="lg"
                >
                  <Link href={`/apply?plan=${plan.id}`}>Choose {plan.name}</Link>
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
