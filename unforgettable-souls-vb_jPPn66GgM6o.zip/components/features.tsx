import { Card } from "@/components/ui/card"
import { Coins, Lock, TrendingUp, Users } from "lucide-react"

const features = [
  {
    icon: Coins,
    title: "Mine & Earn",
    description: "Earn Pi rewards through mining that automatically increase your coverage value",
  },
  {
    icon: TrendingUp,
    title: "Stake to Grow",
    description: "Stake your Pi to accelerate policy growth and compound your coverage over time",
  },
  {
    icon: Lock,
    title: "Blockchain Security",
    description: "All transactions and policy data secured transparently on the blockchain",
  },
  {
    icon: Users,
    title: "Family Protection",
    description: "Comprehensive coverage that protects your loved ones and builds lasting legacy",
  },
]

export function Features() {
  return (
    <section className="px-4 py-20 bg-muted/30">
      <div className="max-w-md mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold text-balance">Insurance Reimagined</h2>
          <p className="text-muted-foreground leading-relaxed">
            Combining traditional life insurance with blockchain innovation
          </p>
        </div>

        <div className="grid gap-4">
          {features.map((feature, index) => (
            <Card key={index} className="p-6 space-y-3 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="space-y-1 flex-1">
                  <h3 className="font-semibold text-lg">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
