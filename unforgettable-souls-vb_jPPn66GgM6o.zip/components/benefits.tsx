import { Card } from "@/components/ui/card"
import { ArrowUpRight, DollarSign, Shield, Zap } from "lucide-react"

export function Benefits() {
  return (
    <section className="px-4 py-20 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="max-w-md mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold text-balance">Why Choose Unforgettable Life</h2>
          <p className="text-muted-foreground leading-relaxed">The future of life insurance is here</p>
        </div>

        <div className="grid gap-6">
          <Card className="p-6 bg-card/80 backdrop-blur border-2">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <DollarSign className="w-7 h-7 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Affordable Premiums</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Low monthly payments that fit any budget, with no hidden fees or surprises
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card/80 backdrop-blur border-2">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center">
                <ArrowUpRight className="w-7 h-7 text-secondary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Growing Coverage</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Your policy value increases automatically through mining rewards and staking
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card/80 backdrop-blur border-2">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Shield className="w-7 h-7 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Transparent & Secure</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Blockchain technology ensures complete transparency and unbreakable security
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card/80 backdrop-blur border-2">
            <div className="space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center">
                <Zap className="w-7 h-7 text-secondary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Fast Claims</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Blockchain verification enables instant payouts when you need them most
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
