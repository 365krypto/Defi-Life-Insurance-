'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { COVERAGE_LEVELS, POLICY_TYPES, calculatePremium } from '@/lib/pricing'
import { Calculator } from 'lucide-react'

const quoteSchema = z.object({
  policyType: z.string().min(1, 'Please select a policy type'),
  coverageLevel: z.string().min(1, 'Please select coverage level'),
  zipCode: z
    .string()
    .min(5, 'ZIP code must be 5 digits')
    .max(5, 'ZIP code must be 5 digits')
    .regex(/^\d+$/, 'ZIP code must contain only numbers'),
  age: z
    .string()
    .min(1, 'Age is required')
    .refine((val) => {
      const num = parseInt(val)
      return num >= 18 && num <= 80
    }, 'Age must be between 18 and 80'),
  email: z.string().email('Please enter a valid email address'),
})

type QuoteFormData = z.infer<typeof quoteSchema>

interface QuoteDialogProps {
  children: React.ReactNode
}

export function QuoteDialog({ children }: QuoteDialogProps) {
  const [open, setOpen] = useState(false)
  const [calculatedPremium, setCalculatedPremium] = useState<number | null>(null)
  const [showResults, setShowResults] = useState(false)
  const router = useRouter()

  const form = useForm<QuoteFormData>({
    resolver: zodResolver(quoteSchema),
    defaultValues: {
      policyType: '',
      coverageLevel: '',
      zipCode: '',
      age: '',
      email: '',
    },
  })

  const onSubmit = (data: QuoteFormData) => {
    const premium = calculatePremium(
      data.coverageLevel,
      parseInt(data.age),
      data.policyType
    )
    setCalculatedPremium(premium)
    setShowResults(true)
  }

  const handleContinue = () => {
    router.push('/apply')
    setOpen(false)
  }

  const handleReset = () => {
    form.reset()
    setCalculatedPremium(null)
    setShowResults(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-primary" />
            {showResults ? 'Your Quote' : 'Get Your Quote'}
          </DialogTitle>
          <DialogDescription>
            {showResults
              ? 'Here\'s your estimated monthly premium'
              : 'Fill out the form below to get an instant quote'}
          </DialogDescription>
        </DialogHeader>

        {!showResults ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="policyType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Policy Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select policy type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {POLICY_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="coverageLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Coverage Level</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select coverage amount" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {COVERAGE_LEVELS.map((level) => (
                          <SelectItem key={level.value} value={level.value}>
                            {level.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="zipCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ZIP Code</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="12345"
                        maxLength={5}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="age"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="30"
                        min={18}
                        max={80}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="your@email.com"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full" size="lg">
                Calculate Premium
              </Button>
            </form>
          </Form>
        ) : (
          <div className="space-y-6">
            <div className="text-center p-8 bg-primary/5 rounded-lg border border-primary/20">
              <p className="text-sm text-muted-foreground mb-2">
                Estimated Monthly Premium
              </p>
              <p className="text-4xl font-bold text-primary">
                ${calculatedPremium}
                <span className="text-lg text-muted-foreground">/mo</span>
              </p>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Policy Type:</span>
                <span className="font-medium">
                  {POLICY_TYPES.find(
                    (t) => t.value === form.getValues('policyType')
                  )?.label}
                </span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Coverage:</span>
                <span className="font-medium">
                  {COVERAGE_LEVELS.find(
                    (l) => l.value === form.getValues('coverageLevel')
                  )?.label}
                </span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Age:</span>
                <span className="font-medium">{form.getValues('age')}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={handleReset}
                className="flex-1"
              >
                New Quote
              </Button>
              <Button onClick={handleContinue} className="flex-1" size="lg">
                Continue to Apply
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
