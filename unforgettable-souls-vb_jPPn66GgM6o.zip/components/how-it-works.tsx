import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

const steps = [
  {
    number: "01",
    title: "Sign Up",
    description: "Join via Pi Network and create your account instantly",
  },
  {
    number: "02",
    title: "Choose Coverage",
    description: "Select an affordable plan that fits your needs",
  },
  {
    number: "03",
    title: "Mine & Stake",
    description: "Earn Pi by mining and stake to increase coverage faster",
  },
  {
    number: "04",
    title: "Grow Value",
    description: "Policy coverage grows automatically with rewards",
  },
  {
    number: "05",
    title: "Blockchain Security",
    description: "All data recorded securely and transparently",
  },
  {
    number: "06",
    title: "Premium Payments",
    description: "Pay low, manageable premiums to keep policy active",
  },
  {
    number: "07",
    title: "Claims & Borrowing",
    description: "Fast payouts or borrow against policy value",
  },
  {
    number: "08",
    title: "Family Benefits",
    description: "Long-term security and lasting financial legacy",
  },
]

export function HowItWorks() {
  return (
    <section className="px-4 py-20">
      <div className="max-w-md mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold text-balance">How It Works</h2>
          <p className="text-muted-foreground leading-relaxed">Eight simple steps to secure your family's future</p>
        </div>

        <div className="space-y-4">
          {steps.map((step, index) => (
            <Card key={index} className="p-5 border-l-4 border-l-primary/50 hover:border-l-primary transition-colors">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center">
                  <span className="text-sm font-bold text-secondary">{step.number}</span>
                </div>
                <div className="space-y-1 flex-1">
                  <h3 className="font-semibold text-base">{step.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
                <CheckCircle2 className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
