export const PLANS = {
  basic: {
    id: 'basic',
    name: 'Basic',
    monthlyPrice: 29,
    annualPrice: 313, // 10% off (29 * 12 * 0.9)
    coverage: '$100,000',
    features: [
      'Whole life coverage',
      'Blockchain-secured policy',
      'Basic mining rewards',
      'Email support',
    ],
  },
  standard: {
    id: 'standard',
    name: 'Standard',
    monthlyPrice: 49,
    annualPrice: 529, // 10% off (49 * 12 * 0.9)
    coverage: '$250,000',
    features: [
      'Enhanced coverage',
      'Priority blockchain rewards',
      'Accelerated mining',
      'Priority support',
      'Family protection add-ons',
    ],
  },
  premium: {
    id: 'premium',
    name: 'Premium',
    monthlyPrice: 79,
    annualPrice: 853, // 10% off (79 * 12 * 0.9)
    coverage: '$500,000',
    features: [
      'Maximum coverage',
      'Premium mining rewards',
      'Staking multipliers',
      '24/7 dedicated support',
      'Family protection included',
      'Investment advisory',
    ],
  },
} as const

export type PlanId = keyof typeof PLANS

export const COVERAGE_LEVELS = [
  { value: '100000', label: '$100,000' },
  { value: '250000', label: '$250,000' },
  { value: '500000', label: '$500,000' },
  { value: '1000000', label: '$1,000,000' },
] as const

export const POLICY_TYPES = [
  { value: 'whole-life', label: 'Whole Life' },
  { value: 'term-life', label: 'Term Life (20 years)' },
  { value: 'universal-life', label: 'Universal Life' },
] as const

/**
 * Calculate monthly premium based on coverage, age, and policy type
 * This is a simplified calculation for demo purposes
 */
export function calculatePremium(
  coverageLevel: string,
  age: number,
  policyType: string
): number {
  // Base premium per $100k coverage
  let basePremium = 15

  // Age multiplier
  const ageMultiplier = 1 + (age - 25) * 0.02

  // Policy type multiplier
  const policyMultipliers: Record<string, number> = {
    'whole-life': 1.5,
    'term-life': 1.0,
    'universal-life': 1.3,
  }

  // Calculate coverage units (in $100k)
  const coverageUnits = parseInt(coverageLevel) / 100000

  const premium =
    basePremium *
    coverageUnits *
    ageMultiplier *
    (policyMultipliers[policyType] || 1.5)

  return Math.round(premium)
}
